export const selectUserId = ({ user }) => user.id;
