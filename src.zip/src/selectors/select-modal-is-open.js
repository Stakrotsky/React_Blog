export const selectModalIsOpen = ({ app }) => app.modal.isOpen;
