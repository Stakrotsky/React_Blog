export const selectModalOnCancel = ({ app }) => app.modal.onCancel;
