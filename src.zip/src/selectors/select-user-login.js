export const selectUserLogin = ({ user }) => user.login;
