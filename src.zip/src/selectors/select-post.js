export const selectPost = ({ post }) => {
	return post;
};
