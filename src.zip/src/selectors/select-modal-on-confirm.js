export const selectModalOnConfirm = ({ app }) => app.modal.onConfirm;
