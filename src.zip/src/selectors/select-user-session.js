export const selectUserSession = ({ user }) => user.session;
