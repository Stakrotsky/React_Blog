export const selectModalText = ({ app }) => app.modal.text;
